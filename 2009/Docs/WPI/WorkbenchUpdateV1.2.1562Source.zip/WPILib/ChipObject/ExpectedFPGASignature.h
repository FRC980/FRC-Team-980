// Copyright (c) National Instruments 2008.  All Rights Reserved.
// Do Not Edit... this file is generated!

#ifndef __ExpectedFPGASignature_h__
#define __ExpectedFPGASignature_h__

namespace nFPGA
{

   static const unsigned short g_ExpectedFPGAVersion = 2009;
   static const unsigned int g_ExpectedFPGARevision = 0x0000100B;
   static const unsigned int g_ExpectedFPGASignature[] = 
   {
      0x306F586F,
      0xB5ADD059,
      0xCDB04298,
      0x21CA506D,
   };

}

#endif // __ExpectedFPGASignature_h__
