#ifndef _C_DIGITAL_OUTPUT_H
#define _C_DIGITIL_OUTPUT_H

void SetDigitalOutput(UINT32 slot, UINT32 channel, UINT32 value);
void SetDigitalOutput(UINT32 channel, UINT32 value);

#endif

