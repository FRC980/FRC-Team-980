#ifndef _C_DIGITAL_INPUT_H
#define _C_DIGITIL_INPUT_H

UINT32 GetDigitalInput(UINT32 slot, UINT32 channel);
UINT32 GetDigitalInput(UINT32 channel);

#endif

