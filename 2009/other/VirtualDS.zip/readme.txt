FRC Virtual Driver Station
--------------------------

Exercise appropriate caution when using this software.  Make sure everyone is
a safe distance away from the robot before running this program.

To start the program, run it from a command prompt with your team number as
the first argument like this:
C:\>VirtualDS 111

The program will start up with the robot disabled.  Use the keyboard commands
below to control the virtual DS.  If 5 or more packets from the robot are
missed, the program will automatically disable the robot and revert to driver
control mode.  If the robot is rebooted with Ctrl-R, the DS will be reverted
to disabled and driver control mode.

Keyboard Command    Action
----------------    -----------------------------------------------
Ctrl-Spacebar       Enable
Spacebar or ESC     Disable
Ctrl-A              Toggle Autonomous/Driver Control mode
Ctrl-R              Reboot robot controller
Tab                 Toggle DS LCD screen display
1-8                 Hold to "turn on" DS digital inputs 1-8
Shift-1             Toggle DS digital input 1 on/off
Shift-2             Toggle DS digital input 2 on/off
...
Shift-8             Toggle DS digital input 8 on/off
